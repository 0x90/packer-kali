function do_main(){
	return_result(result_id, "Redirecting now");	
	window.location = "REDIRECTURL";
}

do_main();