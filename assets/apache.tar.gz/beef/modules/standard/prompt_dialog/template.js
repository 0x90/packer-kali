function do_main(){
	var rtn_value = prompt("PROMPTSTRING");
	return_result(result_id, rtn_value);
}

do_main();