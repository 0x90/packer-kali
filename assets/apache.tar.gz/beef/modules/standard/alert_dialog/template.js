function do_main(){
	alert("ALERTSTRING");
}

do_main();
return_result(result_id, "RTN");